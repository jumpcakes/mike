<?php
/*
Weather Hero v1.6b (October 2013)
Exclusive to http://www.codecanyon.net
(c) 2010-2013 by Davide Gaido
Contact: david.0plus1@gmail.com
Url: http://codecanyon.net/item/weather-hero-geoip-weather-forecast-widget/99701
*/

//This contains the print_rr function, it beautifies the print_r output needed for the debug
require_once 'utils.php';
require_once 'simplexml.class.php';

class WeatherHero{
 
/*-----------------
	Options
----------------*/

//----------------------------------------------------------------Start editing here:
	//Fahrenheit (f) Celsius (c)
	var $unitofmeasure_temp = 'f';
	//Miles per hour (m) Kilometers per hour (k)
	var $unitofmeasure_speed = 'm';
	var $convert_FtoC = false;
	//World Weather Online API
	var $wwo_url = 'http://api.worldweatheronline.com/free/v1/weather.ashx';
	var $wwo_key = 'f82b0aef8bfabc7cbeae47fe6ea5544d172de6df'; //Get you key here: http://developer.worldweatheronline.com/member/register
	//Infodb API
	var $geoip_url = 'http://api.ipinfodb.com/v3/ip-city/';
	var $geoip_key = '1b62fc8b8810654e9707a100864d9a094cbfad6b8d9fe4ed84d64d951c21e1fc'; //Get you key here: http://www.ipinfodb.com/register.php
	//Debug
	var $debug = '0';
//-------------------------------------------------------------------stop editing here	
	
	var $location = '';
 	var $wArray = '';
	var $api_url = '';
	var $counter = '';
	var $wwo_cc = array();
		
		function WeatherHero($location='',$debug='')
		{
			if(empty($this->geoip_key)){
				$this->log_error( 'Missing infodb key', 'FATAL' );
			}
			if(empty($this->wwo_key)){
				$this->log_error( 'Missing wwo key', 'FATAL' );
			}
			//We don't want notices here
			error_reporting(E_ALL ^ E_NOTICE);
			//Create the google api url
			$this->api_url = $this->g_url.$this->g_url_params;
			//We may want to debug
			if ($debug=='debug'){
				$this->debug = '1';
			}
			//We may force a place
			if ($location!=''){
				$this->location = $location;
			} else {
				$this->locateip();
			}	
			
			$this->makeArray();
		}
		
		function getInformations()
		{
			$array = $this->wArray;
			
			unset($array['forecast_conditions']);
			unset($array['current_conditions']);
			
			return $array['forecast_information'];
		}
		function getCurrent()
		{
			$array = $this->wArray;
			
			unset($array['forecast_conditions']);
			unset($array['forecast_information']);
			
			return $array['current_conditions'];
		}
		
		function getForecast()
		{
			$array = $this->wArray;
			
			unset($array['current_conditions']);
			unset($array['forecast_information']);
			
			return $array['forecast_conditions'];
		}
			
		function makeArray()
		{
			// build the url
			$url = $this->wwo_url .'?q='. $this->urlEncode($this->location) . '&format=xml&num_of_days=5&key='.$this->wwo_key;			
			$xml = new simplexml();
			$result = $xml -> xml_load_file($url,'array');
			
			//We check for errors
			if($result['error']['msg'])
			{
				$this->log_error( $result['error']['msg'], 'WWO' );
			}
			
			$return = array();
			$main_array = array();
			//First pass (we strip @attributes)
			$main_array = $result;
			//Forecast Information
			$forecast_information = array();
			$forecast_information = $main_array['request'];
			$return['forecast_information']['city'] = $forecast_information['query'];
			/*$return['forecast_information']['zip'] = $forecast_information['city']['@attributes']['data'];
			$return['forecast_information']['date'] = $forecast_information['city']['@attributes']['data'];
			$return['forecast_information']['date_time'] = $forecast_information['city']['@attributes']['data'];*/
				
			//Current Conditions
			$current_conditions = array();
			$current_conditions = $main_array['current_condition'];
			$return['current_conditions']['condition'] = $current_conditions['weatherDesc'];
			$return['current_conditions']['temp'] = ($this->unitofmeasure_temp=='c')?$current_conditions['temp_C'].' &deg;C':$current_conditions['temp_F']. ' &deg;F';
			$return['current_conditions']['humidity'] = $current_conditions['humidity'] .'%';
			$return['current_conditions']['icon'] = $current_conditions['weatherIconUrl'];
			$return['current_conditions']['wind'] = ($this->unitofmeasure_speed=='k')?$current_conditions['windspeedKmph'][0]. 'Kph':$current_conditions['windspeedMiles'][0]. 'Mph';
			//Custom icons
			$return['current_conditions']['ci'] = $current_conditions['weatherCode'];
			//Forecast Conditions
			$forecast_conditions = array();
 			$forecast_conditions = $main_array['weather'];

			for ($i = 0; $i < count($forecast_conditions); $i++){
				$return['forecast_conditions'][$i]['date'] = $forecast_conditions[$i]['date'];
				$return['forecast_conditions'][$i]['day_of_week'] = date('l', strtotime($forecast_conditions[$i]['date']));
				//If the user need celsius we need to convert.
				if($this->unitofmeasure_temp=='c'){
					$return['forecast_conditions'][$i]['t_low'] = $forecast_conditions[$i]['tempMinC'].' &deg;C';
					$return['forecast_conditions'][$i]['t_high'] = $forecast_conditions[$i]['tempMaxC'].' &deg;C';
					$return['forecast_conditions'][$i]['t_med'] = (($forecast_conditions[$i]['tempMinC']+$forecast_conditions[$i]['tempMaxC'])/2).' &deg;C';
				} else {
					$return['forecast_conditions'][$i]['t_low'] = $forecast_conditions[$i]['tempMinF'].' &deg;F';
					$return['forecast_conditions'][$i]['t_high'] = $forecast_conditions[$i]['tempMaxF'].' &deg;F';
					$return['forecast_conditions'][$i]['t_med'] = (($forecast_conditions[$i]['tempMinF']+$forecast_conditions[$i]['tempMaxF'])/2).' &deg;F';
				}				
				$return['forecast_conditions'][$i]['icon'] = $forecast_conditions[$i]['weatherIconUrl'];
				$return['forecast_conditions'][$i]['condition'] = $forecast_conditions[$i]['weatherDesc'];
				//Custom Icons
				$return['forecast_conditions'][$i]['ci'] = $forecast_conditions[$i]['weatherCode'];
			}
 			$this->counter = $i;
			
			if ($this->debug=='1') {
				echo '<h1>DEBUG WWO API</h1>';
				echo '<p>WWO API has been called with this URL: '.$url.'</p>';
				echo '<p>WWO API has returned this array (SimpleXML): '.print_rr($result).'</p>';
				echo '<p>Weather Hero array manipulation result: '.print_rr($return).'</p>';
			}
			$this->wArray = $return;
 	
		}
		//
		function locateIp()
		{
			
			$ip = $_SERVER["REMOTE_ADDR"];
			$xml = new simplexml();
			
			$url = $this->geoip_url.'?key='.$this->geoip_key.'&ip='/*.$ip.*/.'50.77.58.145'.'&format=xml';
			$result = $xml -> xml_load_file($url,'array');
			
			if ( isset($result['countryName']) && isset($result['regionName']) && isset($result['cityName']) ) {
				$this->location = $result['cityName'].','.$result['regionName'].','.$result['countryName'];
			}
			if ($this->debug=='1') {
				echo '<h1>DEBUG GeoIP</h1>';
				echo '<p>GeoIP has been called with this URL: '.$url.'</p>';
				echo '<p>GeoIP has returned this array (SimpleXML): '.print_rr($result).'</p>';
				echo '<p>GeoIP has returned this location: '.$this->location.'</p>';
			}
			return true;
		}
		//
		function urlEncode($string)
		{	
			$htmlentites = htmlentities($string, ENT_QUOTES, 'UTF-8');
			$firstPass = preg_replace('~&([a-z]{1,2})(acute|cedil|circ|grave|lig|orn|ring|slash|th|tilde|uml);~i', '$1', $htmlentites);
			$secondPass = preg_replace('~[^0-9a-z,]+~i', '+',$firstPass);
			$return = strtolower(trim($secondPass, ' '));
			unset($htmlentites); unset($firstPass); unset($secondPass);
			//
			if ($this->debug=='1') {
				echo '<h1>DEBUG urlEncode</h1>';
				echo '<p>Original string '.$string.'</p>';
				echo '<p>Encoded string: '.$return.'</p>';
			}
			return $return;
		}
		//
		private function log_error($error, $type)
		{
			error_log( date("Y-m-d H:i:s").' - '.'['.$type.'] '.$error."\n" , 3, 'wh/logs/errors.log');
		}

	}
 
?>