<?php

function print_rr($array){
	if(is_array($array)){
		foreach($array as $key=>$value){
		   if(is_array($value)){
			  $id = md5(rand());
			  echo '[<a href="#" onclick="return expandParent(\''.$id.'\')">'.$key.'</a>]<br />';
			  echo '<div id="'.$id.'" style="display:none;margin:10px;border-left:1px solid; padding-left:5px;">';
			  print_rr($value, $count);
			  echo '</div>';
		   } else {
		   echo "<b>$key</b>: ".$value."<br />";
		   }
		}
		echo '<script language="Javascript">
		function expandParent(id){toggle="block";if(document.getElementById(id).style.display=="block"){toggle="none"}document.getElementById(id).style.display=toggle;return false;};
		</script>';
	} else {
		echo '<p>Empty Data</p>';
	}
}

?>