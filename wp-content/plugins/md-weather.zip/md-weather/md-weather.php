<?php
/**
 * Plugin Name: Name Of The Plugin
 * Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates
 * Description: A brief description of the Plugin.
 * Version: The Plugin's Version Number, e.g.: 1.0
 * Author: Name Of The Plugin Author
 * Author URI: http://URI_Of_The_Plugin_Author
 * License: A "Slug" license name e.g. GPL2
 */
?>


<?php
function md_scripts() {
	wp_enqueue_style( 'style', plugins_url( 'myscript.js', __FILE__ ) );
}
add_action( 'wp_enqueue_scripts', 'md_scripts' );
?>

<link rel="stylesheet" href="css/style.css" type="text/css">

<?php 
	//We need the class
	require_once 'php/wh.class.php';
	
	//Class calling
	$wh = new WeatherHero('','');//You can call the class with the debug option, this will print debug info only for that call
	//This method gets the info about the current location (needed since the google API splits these info)
	$informations = $wh->getInformations();
	//This method get the forecast for the next 5 days. It comes back inside an array. If you want to see what kind of information comes back please activate the debug mode.
	$current = $wh->getCurrent();
?>
<div id="container">
       

<?php if(is_array($current)&&!empty($current)) { ?>
    	<h2>Temperature in <span><?php echo $informations['city'];?></span>: <?php echo $current['temp'];?></h2>                                        
<?php } else { ?>
        <h2>Sorry, we don't have weather data for your location</h2>
<?php } ?>
               
               
               
                      
<?php 
if (isset($_COOKIE['showstuff'])) {
	exit;
} elseif (!isset($_COOKIE['showstuff'])) {
    setcookie('showstuff', true,  time()+8); // 1 day
}; 
?>
   
   
   
   
                                
<?php

$highTemp = 150;
$lowTemp = 120;
$actualTemp = substr($current['temp'], 0, 2);

function temperature_popup_exists() {
	global $highTemp, $lowTemp, $actualTemp;
	if (($actualTemp > $highTemp) || ($actualTemp < $lowTemp)) {
		return true;
	};
}

function temperature_popup() {
	global $highTemp, $lowTemp, $actualTemp;
	if (temperature_popup_exists()) {

	if ($actualTemp > $highTemp) {
    	echo '<div class="temp-widget">';
    		echo '<h3>Current Temperature Widget <span>(' . $actualTemp . ')</span></h3>';
    		echo '<p>It\'s Hot, so we\'re offering a discount on air conditioning services.</p>';
    	echo '</div>';
    	}
    	
   	elseif ($actualTemp < $lowTemp) {
   		echo '<div class="temp-widget">';
   		echo '<h3>Current Temperature Widget <span>(' . $actualTemp . ')</span></h3>';
    	echo '<p>It\'s Cold, so we\'re offering a discount on heating services.</p>';
    	echo '</div>';
	} else {};
    };
};
    		
temperature_popup();		

?>  				
    				
    			


    
    
</div>

</body>

</html>
